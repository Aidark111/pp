print(10*5)
print(10 / 2)
# Use the correct membership operator to check if "apple" is present in the fruits object.
fruits = ["apple", "banana"]
if "apple" in fruits:  # in
    print("Yes, apple is a fruit!")
# Use the correct comparison operator to check if 5 is not equal to 10.
if 5 != 10:
    print("5 and 10 is not equal")
# Use the correct logical operator to check if at least one of two statements is True.

if 5 == 10 or 4 == 4:
    print("At least one of the statements is true")