# Print "Hello World" if a is greater than b.

a = 50
b = 10
if a > b:
    print("Hello World")
# Print "Hello World" if a is not equal to b.

a = 50
b = 10
if a != b:
    print("Hello World")
 # Print "Yes" if a is equal to b, otherwise print "No".

a = 50
b = 10
if a == b:
    print("Yes")
else:
    print("No")
# Print "1" if a is equal to b, print "2" if a is greater than b, otherwise print "3".

a = 50
b = 10
if a == b:
    print("1")
elif a > b:
    print("2")
else:

    print("3")
# Print "Hello" if a is equal to b, and c is equal to d.

a = 1
b = 1
c = 1
d = 1

if a == b and c == d:
    print("Hello")
# Print "Hello" if a is equal to b, or if c is equal to d.

a, b, c, d = 1, 1, 1, 1


if a == b or c == d:
    print("Hello")
# Insert the missing indentation to make the code correct:

if 5 > 2:
    print("Five is greater than two!")
# Use the correct short hand syntax to put the following statement on one line:


if 5 > 2:
    print("Five is greater than two!")

# Use the correct short hand syntax to write the following conditional expression in one line:

print("Yes") if 5 > 2 else print("No")