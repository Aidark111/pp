# # If statement:

# a = 33
# b = 200
# if b > a:
#   print("b is greater than a")

# # If statement, without indentation (will raise an error):

# a = 33
# b = 200
# if b > a:
# print("b is greater than a") # you will get an error

# a = 33
# b = 33
# if b > a:
#   print("b is greater than a")
# elif a == b:
#   print("a and b are equal")

# a = 200
# b = 33
# if b > a:
#   print("b is greater than a")
# elif a == b:
#   print("a and b are equal")
# else:
#   print("a is greater than b")  

a = 200
b = 33
if b > a:
  print("b is greater than a")
else:
  print("b is not greater than a")
